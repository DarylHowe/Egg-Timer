package com.DarylHoweDevs.PerfectEgg;

import android.os.CountDownTimer;
import android.util.Log;

public class EggTimer extends MainActivity {

    // instance variables
   private CountDownTimer mainCountDown;
   private int progressInstance;
   private String timerString = "jhj";

    // constructor(s)
    public EggTimer(){

    }

    public void setEggTimer(int progress){
        this.progressInstance = progress;
        updateTimer(progressInstance);

        Log.i("setEggTimer", Integer.toString(progressInstance));
    }

    public void timerCountdown(){

        //start the mainCountDown timer
        mainCountDown = new CountDownTimer(progressInstance * 1000, 1000) {

            public void onTick(long mileSecondsUntilDone) {

                // every tick pass seconds left .ie 'mileSecondsUntilDone / 1000' into updateTimer method
                updateTimer((int) mileSecondsUntilDone / 1000);
            }

            // when timer has finished
            public void onFinish() {

                // need to call the timerFinishedUI() in MainActivity ** PLEASE HELP **
                //   timerFinishedUI();

                // allow the animation to play out
                new CountDownTimer(4000, 1000) {
                    public void onTick(long ms) {
                    }
                    public void onFinish() {
                        cancelMainCountDown();

                        // need to call the resetTimerUI() in MainActivity ** PLEASE HELP **
                        //           resetTimerUI();
                    }
                }.start();
            }
        }.start();
    }

    public void cancelMainCountDown(){
        mainCountDown.cancel();


    }

    /**
     * A method to update the timer time.
     * 'secondsLeft' taken from countdown after 'COOK!' button is pressed
     */
    public void updateTimer(int secondsLeft){
       // Log.i("egg timer seconds left", Integer.toString(secondsLeft));

        int minutes = secondsLeft /60;
        int seconds = secondsLeft - (minutes*60);

        String secondString = Integer.toString(seconds);
        if(seconds <= 9){
            secondString = "0" + secondString;
        }

        timerString = minutes + ":" + secondString;

        // we need to call the updateTimerUI() in MainActivity ** PLEASE HELP **
        //updateTimerUI();

        Log.i("egg timer timerString", timerString);
    }

    public String getTimerString(){

        if ( ! timerString.isEmpty() ) {
            return timerString;
        } else {
            return "";
        }
    }
}
