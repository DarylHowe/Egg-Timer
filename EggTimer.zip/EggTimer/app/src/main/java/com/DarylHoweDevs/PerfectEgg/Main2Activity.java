package com.DarylHoweDevs.PerfectEgg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.DarylHoweDevs.PerfectEgg.R;

public class Main2Activity extends AppCompatActivity {

    // declare variables

    TextView textHeader;
    TextView textInstructions01;
    TextView textInstructions02;
    TextView textInstructions03;
    TextView textInstructions04;

    ImageView boilingWaterImage;

    int animationDuration = 500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // link UI elements to variable names

        textHeader = (TextView)findViewById(R.id.InstuctionsHeaderText);
        textInstructions01 = (TextView)findViewById(R.id.InstructionsText01);
        textInstructions02 = (TextView)findViewById(R.id.InstructionsText02);
        textInstructions03 = (TextView)findViewById(R.id.InstructionsText03);
        textInstructions04 = (TextView)findViewById(R.id.InstructionsText04);

        boilingWaterImage = (ImageView)findViewById(R.id.boilingWaterImage);

        // set elements initial alpha state to 0 .ie invisible on start
        textHeader.setAlpha(0);
        textInstructions01.setAlpha(0);
        textInstructions02.setAlpha(0);
        textInstructions03.setAlpha(0);
        textInstructions04.setAlpha(0);

        // fade elements alpha state over time
        textHeader.animate().alpha(1).setDuration(animationDuration);
        textInstructions01.animate().alpha(1).setDuration(animationDuration + 1000);
        textInstructions02.animate().alpha(1).setDuration(animationDuration + 1500);
        textInstructions03.animate().alpha(1).setDuration(animationDuration + 2000);
        textInstructions04.animate().alpha(1).setDuration(animationDuration + 2000);

        boilingWaterImage.animate().alpha(1).setDuration(animationDuration + 1500);
    }

    // load main screen
    public void loadMainActivity(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }



}
