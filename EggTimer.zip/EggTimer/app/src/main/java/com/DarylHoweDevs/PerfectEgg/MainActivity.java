package com.DarylHoweDevs.PerfectEgg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.DarylHoweDevs.PerfectEgg.R;

public class MainActivity extends AppCompatActivity {

    // declare variables

    TextView countDownText;
    TextView eggOutcomeText;

    Button cookResetButton;

    ImageView cookedEggImage;
    ImageView eggImage;

    CountDownTimer mainCountDown;
    CountDownTimer animationCountDown;

    SeekBar seekBar;

    MediaPlayer roosterAudioSample;
    Vibrator vibe;

    boolean counterIsActive = false;

    EggTimer eggTimer;

    int progress1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // link UI elements to variable names

        countDownText = (TextView) findViewById(R.id.countdownText);
        cookedEggImage = (ImageView) findViewById(R.id.cookedEggImage);
        eggImage = (ImageView) findViewById(R.id.eggImage);
        seekBar = (SeekBar) findViewById(R.id.setTimeSeekBar);
        eggOutcomeText = (TextView) findViewById(R.id.eggOutcomeText);

        roosterAudioSample = MediaPlayer.create(this, R.raw.roostersoundclip);


        // set 'cookedEggImage' to invisible
        // set 'cookedEggImage' to outside of screen bounds
        cookedEggImage.setVisibility(View.INVISIBLE);
        cookedEggImage.setTranslationY(-1200);

        vibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);


        // set time initially to '5:00'
        countDownText.setText("5:00");

        // set egg outcome text initially to 'MEDIUM'
        eggOutcomeText.setText("MEDIUM");

        setCookingTimeBar();
    }


    /**
     * A method to allow user to set egg cooking time duration via the UI seek bar.
     * Seek bar max and initial values set.
     * The UI text element 'eggOutcomeText' will change according to the time duration set by user.
     */
    public void setCookingTimeBar() {

        // set seek bar max value
        // set seek bar inital value

        int maxValue = 600;
        int initialValue = 300;
        seekBar.setMax(maxValue);
        seekBar.setProgress(initialValue);


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, final int progress, boolean fromUser) {
                updateTimer(progress);

                // change eggOutcomeText depending on how long user sets the time for

                if(progress <= 100 ){
                    eggOutcomeText.setText("RAW");
                } else if (progress > 100 && progress <= 200) {
                    eggOutcomeText.setText("SOFT");
                } else if (progress > 200 && progress <= 420) {
                    eggOutcomeText.setText("MEDIUM");
                } else if (progress > 420) {
                    eggOutcomeText.setText("HARD");
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
    }


    /**
     * A method to start or reset the egg timer depending on its previous state.
     * If the timer is already active - the time will be reset.
     * If the timer is not already active - the timer will begin.
     */
    public void cookResetButtonPresser(View view) {

        cookResetButton = (Button) view;

        // if reset button has been pressed
        if (counterIsActive) {
            resetTimer();
            countDownText.animate().translationY(400).rotation(1800).setDuration(2000);

            // if cook button has been pressed
        } else {
            counterIsActive = true;
            seekBar.setEnabled(false);
            cookResetButton.setText("RESET!");

            //start the mainCountDown timer
            mainCountDown = new CountDownTimer(seekBar.getProgress() * 1000, 1000) {
                public void onTick(long mileSecondsUntilDone) {

                    // every tick pass seconds left .ie 'mileSecondsUntilDone / 1000' into updateTimer method
                    updateTimer((int) mileSecondsUntilDone / 1000);
                }

                // when timer has finished
                public void onFinish() {

                    // play audio sample and vibrate device
                    roosterAudioSample.start();
                    vibe.vibrate(3000);

                    // hide cookResetButton
                    cookResetButton.setVisibility(View.INVISIBLE);

                    // fade out cartoon egg image
                    eggImage.animate().alpha(0).rotation(720).setDuration(2000);

                    // set visible and animate cookedEggImage
                    cookedEggImage.setVisibility(View.VISIBLE);
                    cookedEggImage.animate().translationYBy(1200).rotation(360).setStartDelay(1000).setDuration(1500);

                    // animate and display "YOUR EGG IS COOKED!"
                    countDownText.animate().translationY(400).rotation(720).setDuration(2000);
                    countDownText.setText("YOUR EGG IS COOKED!");

                    // allow the animation to play out
                    new CountDownTimer(4000, 1000) {
                        public void onTick(long ms) {
                        }

                        public void onFinish() {
                            resetTimer();
                        }
                    }.start();
                }
            }.start();
        }
    }


    /**
     * A method to reset the egg timer back to its initial state.
     */
    public void resetTimer() {

        // animate out cookedEggImage and set invisible
        cookedEggImage.animate().translationY(-1200).rotation(720).setDuration(1500);

        // animate fade out on countDownText
        countDownText.animate().alpha(0).setDuration(1000);

        // disable cookResetButton
        cookResetButton.setEnabled(false);

        mainCountDown.cancel();

        // 2 second countdown to allow animations to play out
        animationCountDown = new CountDownTimer(2000, 1000) {
            public void onTick(long ms) {
            }

            // reset UI elements after egg has cooked and animation has played
            public void onFinish() {
                counterIsActive = false;
                seekBar.setEnabled(true);
                cookResetButton.setText("COOK!");

                countDownText.animate().alpha(1).setDuration(1500);
                countDownText.setText("5:00");

                seekBar.setProgress(300);

                animationCountDown.cancel();

                countDownText.animate().translationYBy(-400).rotation(-720);

                eggImage.animate().alpha(1).rotationBy(1800).setDuration(1500);

                cookResetButton.setVisibility(View.VISIBLE);
                cookResetButton.setEnabled(true);
            }
        }.start();
    }


    /**
     * A method to update the UI timer time.
     * 'secondsLeft' taken from countdown after 'COOK!' button is pressed
     */
    public void updateTimer(int secondsLeft) {

        final int minutes = secondsLeft / 60;
        final int seconds = secondsLeft - (minutes * 60);

        String secondString = Integer.toString(seconds);
        if (seconds <= 9) {
            secondString = "0" + secondString;
        }
        countDownText.setText(minutes + ":" + secondString);
    }


    /**
     * A method to load the instructions screen when UI element is pressed
     */
    public void instructionsButtonPressed(View view) {
        Intent intent = new Intent(this, Main2Activity.class);
        startActivity(intent);
    }



}
