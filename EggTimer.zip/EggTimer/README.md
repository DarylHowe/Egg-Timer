Egg Timer
=====
 * Author @ Daryl Howe 02/03/2020
 * Contact - howedaryl@hotmail.com


Description
============
'Egg Timer' is an Android application which allows the user to time and cook an egg to their taste!

Instructions
============ 
Use the following link to install the application onto an Android mobile device.
* https://play.google.com/store/apps/details?id=com.DarylHoweDevs.PerfectEgg

Egg Timer is a self driven project and was chosen as a way to learn about the Android framework and 
mobile application development.